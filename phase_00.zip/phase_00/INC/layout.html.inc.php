<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title><?= $accuil ?></title>
    <!-- La feuille de styles "base.css" doit être appelée en premier. -->
    <link rel="stylesheet" type="text/css" href=CSS/base.css media="all" />
    <link rel="stylesheet" type="text/css" href=CSS/modele04.css media="screen" />
    <link rel="stylesheet" type="text/css" href=CSS/index.css media="screen" />
    <script type="text/javascript" src="JS/utils.js"></script>
    <script type="text/javascript" src="JS/index.js"></script>
</head>

<body>

<div id="global">

    <header id="entete">
        <h1 >
            <img id = logo alt="<?= $alt ?>" src="<?= $logo ?>" />
            <?= $titre ?>
        </h1>
        <nav id="menu" class="menu">
            <ul>
                <li><a href="index.html" onclick=' return ajaxHTML(this);'>Accueil</a></li>
                <li><a href="liste.html" onclick=' return ajaxHTML(this);'>Tous les gabarits</a></li>
                <li><a href="tableau.html" onclick=' return ajaxJSON(this);'>JSON</a></li>
            </ul>
        </nav><!-- #navigation -->
    </header ><!-- #entete -->

    <nav id="navigation" class="menu">
        <ul>
            <li><a href="utiliser.html"  onclick=' return ajaxHTML(this);'>Utilisation</a></li>
            <li><a href="licence.html"  onclick=' return ajaxHTML(this);'>Licence</a></li>
            <li><a href="credits.html"  onclick=' return ajaxHTML(this);'>Crédits</a></li>
        </ul>
    </nav><!-- #navigation -->

    <main id="contenu">
      <?= $contenue ?>
    </main><!-- #contenu -->

    <footer id="copyright" onmouseover="init1();" onmouseover="init2();">
        <span class="auteur" title="<?= $mail ?>"><a href="mailto:<?= $mail ?>"><?= $auteur ?></a></span> -
        <span>credits</span>
        <span id="credit" class="credit" >

            Mise en page &copy; 2008
            <a href="http://www.elephorm.com" target="_blank">Elephorm</a> et
            <a href="http://www.alsacreations.com" target="_blank">Alsacréations</a>
        </span>

    </footer>

</div><!-- #global -->

</body>
</html>

