<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>
        Gabarit 04: minima, menu vertical à gauche, largeur fluide
    </title>
    <!-- La feuille de styles "base.css" doit être appelée en premier. -->
    <link rel="stylesheet" type="text/css" href=CSS/base.css media="all" />
    <link rel="stylesheet" type="text/css" href=CSS/modele04.css media="screen" />
</head>

<body>

<div id="global">

    <header id="entete">
        <h1>
            <img id = logo alt="<?= $alt ?>" src="<?= $logo ?>" />
            Gabarit 04
        </h1>
        <p class="sous-titre">
            <strong>Caractéristiques:</strong>
            minimaliste,
            menu vertical à gauche,
            largeur fluide
        </p>
    </header><!-- #entete -->

    <nav id="navigation">
        <ul>
            <li><a href="index.html">Accueil</a></li>
            <li><a href="liste.html">Tous les gabarits</a></li>
            <li><a href="utiliser.html">Utilisation</a></li>
            <li><a href="licence.html">Licence</a></li>
            <li><a href="credits.html">Crédits</a></li>
        </ul>
    </nav><!-- #navigation -->

    <main id="contenu">
        <h2>À propos du gabarit 04</h2>
        <h3>Code HTML et CSS</h3>
        <p>Ce gabarit est structuré de la manière suivante:</p>
<pre><code>&lt;div id="global"&gt;
        &lt;div id="entete"&gt;...&lt;/div&gt;
        &lt;div id="navigation"&gt;...&lt;/div&gt;
        &lt;div id="contenu"&gt;...&lt;/div&gt;
        &lt;/div&gt;</code></pre>
        <p>Il est mis en forme par deux feuilles de styles:</p>
        <ol>
            <li><a href="styles/base.css">base.css</a> (mise en forme minimale
                du texte, commune à tous les gabarits)</li>
            <li><strong><a href="styles/modele04.css">modele04.css</a></strong>,
                qui contient tous les styles propres à ce gabarit, et que je vous
                invite à consulter.</li>
        </ol>
        <p>Pour voir le détail du code HTML de cette page, utilisez la fonction
            d'affichage de la source de votre navigateur web (ex: «Affichage &gt;
            Code source de la page»).</p>
        <h3>À noter</h3>
        <ol>
            <li><p>Dans ce gabarit, nous utilisons la propriété CSS
                    <code>float</code> pour placer deux blocs à la même hauteur plutôt
                    que l'un en dessous de l'autre. Voir les notes de la feuille de
                    style du gabarit pour en savoir plus.</p></li>
            <li><p>Le bloc de droite n'utilise pas la propriété
                    <code>float</code>, mais une simple marge à gauche
                    (<code>margin-left</code>).</p>
                <p>Pour mieux comprendre le fonctionnement du positionnement
                    flottant, vous pouvez, avec un outil tel que
                    <a href="https://addons.mozilla.org/fr/firefox/addon/1843">Firebug</a>,
                    désactiver la marge de gauche de <code>div#contenu</code>.</p></li>
        </ol>
    </main><!-- #contenu -->

    <footer id="copyright">
        Mise en page &copy; 2008
        <a href="http://www.elephorm.com">Elephorm</a> et
        <a href="http://www.alsacreations.com">Alsacréations</a>
    </footer>

</div><!-- #global -->

</body>
</html>

