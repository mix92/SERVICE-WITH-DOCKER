<?php
include "INC/dbConnect.inc.php";
// variable a metre dans la page
$accuil = "Accuil";
$titre = "Nom de mon site";
$logo = "IMG/04.png";
$alt = "logo";
$contenue = "Bienvenue";
$auteur = $__INFOS__['nom'] . " " . $__INFOS__['prenom'];
$mail = $__INFOS__['matricule'] . "@students.ephec.be";
//$auteur = <?= $__INFOS__[5].$__INFOS__[6]
include "INC/layout.html.inc.php";
?>