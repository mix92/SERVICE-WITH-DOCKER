# traefik-as-a-reverse-proxy
Using Traefik as a reverse proxy to run multiple applications on one Docker Host.
